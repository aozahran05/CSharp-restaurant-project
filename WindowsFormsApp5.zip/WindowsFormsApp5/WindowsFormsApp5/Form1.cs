﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.TaskbarClock;

namespace WindowsFormsApp5
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        double subTotal = 0, tax, Total;
        

        private void mainCB_SelectedIndexChanged(object sender, EventArgs e)
        {
            string selectedItem = mainCB.SelectedItem.ToString();
            if (selectedItem == "Seafood alfredo")
            {
                subTotal += 15.95;
            }
            else if (selectedItem == "Chicken alfredo")
            {
                subTotal += 13.95;            
            }
            else if (selectedItem == "Chicken picatta")
            {
                subTotal += 13.95;
            }
            else if (selectedItem == "Turkey club")
            {
                subTotal += 11.95;
            }
            else if (selectedItem == "Lobster pie")
            {
                subTotal += 19.95;
            }
            else if (selectedItem == "Prime rib")
            {
                subTotal += 20.95;
            }
            else if (selectedItem == "Shrimp scampi")
            {
                subTotal += 18.95;
            }
            else if (selectedItem == "Turkey dinner")
            {
                subTotal += 13.95;          
            }
            else if (selectedItem == "Stuffed chicken")
            {
                subTotal += 14.95;
            }
        }


        private void dessertCB_SelectedIndexChanged(object sender, EventArgs e)
        {
            string selectedItem = dessertCB.SelectedItem.ToString(); // Adjusted to reference the correct ComboBox
            if (selectedItem == "Apple pie")
            {
                subTotal += 5.95;
            }
            else if (selectedItem == "Sundae")
            {
                subTotal += 3.95;
            }
            else if (selectedItem == "Carrot cake")
            {
                subTotal += 5.95;
            }
            else if (selectedItem == "Mud pie")
            {
                subTotal += 4.95;
            }
            else if (selectedItem == "Apple crisp")
            {
                subTotal += 5.95;
            }
        }


        private void subtotalTxt_TextChanged(object sender, EventArgs e)
        {

        }

        private void taxTB_TextChanged(object sender, EventArgs e)
        {

        }

        private void totalTxt_TextChanged(object sender, EventArgs e)
        {

        }



        private void appetizerCB_SelectedIndexChanged(object sender, EventArgs e)
        {
            string selectedItem = appetizerCB.SelectedItem.ToString(); // Corrected the ComboBox reference to appetizerCB
            if (selectedItem == "Buffalo wings")
            {
                  subTotal += 5.95;
            }
            else if (selectedItem == "Buffalo fingers")
            {
                 subTotal += 6.95;
            }
            else if (selectedItem == "Potato skins")
            {
                subTotal += 8.95;
            }
            else if (selectedItem == "Nachos")
            {
                subTotal += 8.95;
            }
            else if (selectedItem == "Mushroom Caps")
            {
                subTotal += 10.95;
            }
            else if (selectedItem == "Shrimp cocktail")
            {
                subTotal += 12.95;
            }
            else if (selectedItem == "Chips and Salsa")
            {
                subTotal += 6.95;
            }
        }



        private void BeverageCB_SelectedIndexChanged(object sender, EventArgs e)
        {
            string selectedItem = BeverageCB.SelectedItem.ToString(); // Adjusted to reference the correct ComboBox
            if (selectedItem == "Soda")
            {
                subTotal += 1.95;
            }
            else if (selectedItem == "Tea")
            {
                subTotal += 1.5;
            }
            else if (selectedItem == "Coffee")
            {
                subTotal += 1.25;
            }
            else if (selectedItem == "Mineral water")
            {
                subTotal += 2.95;
            }
            else if (selectedItem == "Juice")
            {
                subTotal += 2.5;
            }
            else if (selectedItem == "Milk")
            {
                subTotal += 1.5;
            }
            
        }

    private void button1_Click(object sender, EventArgs e)
        {
            subtotalTxt.Text = $"${subTotal}";
            tax = subTotal * 0.16;
            Total = tax + subTotal;
            taxTB.Text = $"${tax}";
            totalTxt.Text = $"${Total}";
            subTotal = 0;
            Total = 0;
            tax = 0;
        }
    }
}